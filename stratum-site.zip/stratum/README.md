# Stratum

Откройте index.html в браузере или start-site.cmd (нужен Node.js).

Компания: презентация, направления, SHELL, ITBonch и бот-секретарь. Внизу — компактное портфолио и медиатека.
Анимация включена постоянно. Логотип сам переводит взгляд и моргает; на касание отвечает движением.
Для SHELL использована иллюстрация из исходного экспорта. Для ITBonch и бота Макса — предоставленные скриншоты. Ссылка на Telegram-бота не предоставлена.

## Публичная ссылка через GitHub Pages
1. Откройте https://github.com/Rench58/Rench58 — существующий репозиторий сайта.
2. Add file → Upload files. Загрузите index.html, style.css, app.js и папку assets из этой папки в корень репозитория. Не загружайте ZIP вместо файлов и не добавляйте лишнюю внешнюю папку stratum.
3. Commit changes. При совпадении имён обновите существующие файлы.
4. Settings → Pages → Source: Deploy from a branch → main → /(root) → Save. Если основная ветка называется иначе, выберите её.
5. Дождитесь успешного pages build and deployment на вкладке Actions.
6. Ссылка: https://rench58.github.io/Rench58/

Сайт статический, Node.js на GitHub не нужен. server.cjs и start-site.cmd предназначены только для локального просмотра.
Если создаёте отдельный публичный репозиторий stratum, адрес будет https://rench58.github.io/stratum/.
Документация: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
